//1. Given an integer greater than 999. Using one integer division and one modulo
//operation, find the digit corresponding to the thousandth place in the record of this
//number. Дано целое число, большее 999. Используя одно целое деление и одну
//операцию по модулю, найдите цифру, соответствующую тысячному месту в записи этого
//числа.


fun findDigitNumb(Value:Int): Int {
    return ((Value.mod(10000).div(1000)))
}



//2. Since the beginning of the day, N seconds have passed (N is an integer). Find the
//number of full minutes that have passed since the beginning of the day.
//2. С начала дня прошло N секунд (N - целое число). Найдите
//количество полных минут, прошедших с начала дня.



//3.N seconds have passed since the beginning of the day (N is an integer). Find the
//number of complete hours that have passed since the beginning of the day.


//4.N seconds have passed since the beginning of the day (N is an integer). Find the
//number of seconds elapsed since the beginning of the last minute.


//5.N seconds have passed since the beginning of the day (N is an integer). Find the
//number of seconds since the beginning of the last hour.


//6.N seconds have passed since the beginning of the day (N is an integer). Find the
//number of full minutes that have passed since the beginning of the last hour.


//7. Days of the week are numbered as follows: 0 - Sunday, 1 - Monday, 2 - Tuesday, ..., 6 -
//Saturday. You are given an integer K in the range 1–365. Determine the number of the day
//of the week for the K-th day of the year, if it is known that this year January 1 was
//Monday.


//8. Days of the week are numbered as follows: 0 - Sunday, 1 - Monday, 2 - Tuesday, ..., 6 -
//Saturday. You are given an integer K in the range 1–365. Determine the number of the day
//of the week for the K-th day of the year, if it is known that this year January 1 was
//Thursday.


//9. Days of the week are numbered as follows: 1 - Monday, 2 - Tuesday,. ... ... , 6 -
//Saturday, 7 - Sunday. You are given an integer K in the range 1–365. Determine the
//number of the day of the week for the K-th day of the year, if it is known that this year
//January 1 was Tuesday.
fun findDay(){
}
//9. Дни недели нумеруются следующим образом: 1 - понедельник, 2 - Вторник,. ... ... , 6 -
//Суббота, 7 - Воскресенье. Вам дается целое число K в диапазоне 1-365. Определить
////номер дня недели для K-го дня года, если известно, что в этом году
//1 января был вторник.
fun main(){

}